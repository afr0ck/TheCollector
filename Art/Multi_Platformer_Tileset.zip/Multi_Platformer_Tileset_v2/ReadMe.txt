---------------------------------------
Multi Platformer Tileset
Version 4.8 - Snowland Makeup

Made and distributed by Shackhal
https://shackhal.itch.io/
2016-2018

---------------------------------------

Thank you very much for buying this tileset package. It helps me to keep this going. Check the examples to see the capabilities of the tilesets. And create worlds with it :D

The license is CC0 (Creative Commons Zero), so the content is free to use in any personal, educational and commercial projects.
Giving credits (Diego del Solar or "Shackhal") is not mandatory, but greatly appreciated.

---------------------------------------

You can give feedback or add requests here:
https://shackhal.itch.io/multi-platformer-tileset/community

Follow me for updates and more:

Twitter: @shackhal
Blog: http://shackhal.tumblr.com/



